<?php
define("DB_HOST", "127.0.0.1"); //mysql_host
define("DB_USER", "root"); //mysql_user_name
define("DB_PASS", "sbkey00123"); //mysql_user_pwd
define("DB_NAME", "pentest"); //mysql_db_name
?>
